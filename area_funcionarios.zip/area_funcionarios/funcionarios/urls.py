
from django.urls import path
from .views import (
    home,
    LoginFuncionarioView,
    LogoutFuncionarioView,
    PainelView,
    PerfilView,
)

urlpatterns = [
    path('', home, name='home'),
    path('login/', LoginFuncionarioView.as_view(), name='login'),
    path('logout/', LogoutFuncionarioView.as_view(), name='logout'),
    path('painel/', PainelView.as_view(), name='painel'),
    path('perfil/', PerfilView.as_view(), name='perfil'),
]
