
from django.shortcuts import render
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView


def home(request):
    return render(request, 'funcionarios/home.html')


class LoginFuncionarioView(LoginView):
    template_name = 'funcionarios/login.html'


class LogoutFuncionarioView(LogoutView):
    pass


class PainelView(LoginRequiredMixin, TemplateView):
    template_name = 'funcionarios/painel.html'


class PerfilView(LoginRequiredMixin, TemplateView):
    template_name = 'funcionarios/perfil.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['funcionario'] = self.request.user
        return context
